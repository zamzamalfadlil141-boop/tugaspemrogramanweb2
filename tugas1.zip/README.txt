Cara menjalankan:
1. Ekstrak file zip ini.
2. Buka terminal di folder hasil ekstrak.
3. Jalankan 'npm install'.
4. Jalankan 'npm start' atau 'node app.js'.
5. Gunakan extension REST Client di VS Code untuk mencoba test.http.